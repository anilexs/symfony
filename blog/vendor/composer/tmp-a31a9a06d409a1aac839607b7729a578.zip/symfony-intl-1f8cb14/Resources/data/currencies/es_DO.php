<?php

return [
    'Names' => [
        'DOP' => [
            'RD$',
            'peso dominicano',
        ],
        'USD' => [
            'US$',
            'dólar estadounidense',
        ],
    ],
];
