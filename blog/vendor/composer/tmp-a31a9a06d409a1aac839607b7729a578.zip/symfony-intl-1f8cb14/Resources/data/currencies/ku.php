<?php

return [
    'Names' => [
        'EUR' => [
            '€',
            'ewro',
        ],
        'TRY' => [
            '₺',
            'TRY',
        ],
    ],
];
