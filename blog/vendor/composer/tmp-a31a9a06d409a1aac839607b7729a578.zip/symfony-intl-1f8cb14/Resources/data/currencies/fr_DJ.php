<?php

return [
    'Names' => [
        'DJF' => [
            'Fdj',
            'franc djiboutien',
        ],
    ],
];
