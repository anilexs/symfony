<?php

return [
    'Names' => [
        'GTQ' => [
            'Q',
            'quetzal',
        ],
    ],
];
