<?php

return [
    'Names' => [
        'LRD' => [
            '$',
            'Dolaar Liberiyaa',
        ],
    ],
];
