<?php

return [
    'Names' => [
        'AED' => [
            'AED',
            'United Arab Emirates Dirham',
        ],
    ],
];
