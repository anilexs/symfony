<?php

return [
    'Names' => [
        'STN' => [
            'Db',
            'dobra de São Tomé e Príncipe',
        ],
    ],
];
