<?php

return [
    'Names' => [
        'PYG' => [
            'Gs.',
            'guaraní paraguayo',
        ],
    ],
];
