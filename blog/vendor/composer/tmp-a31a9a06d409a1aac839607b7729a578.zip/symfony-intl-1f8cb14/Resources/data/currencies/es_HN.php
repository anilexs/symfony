<?php

return [
    'Names' => [
        'HNL' => [
            'L',
            'lempira hondureño',
        ],
    ],
];
